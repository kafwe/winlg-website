class Triple:
    def __init__(self, subject: str, predicate: str, object: str, constructor: str):
        self.subject = subject
        self.predicate = predicate
        self.object = object
        self.constructor = constructor

    def __str__(self):
        return f"wdt:{self.predicate} wd{self.object}"