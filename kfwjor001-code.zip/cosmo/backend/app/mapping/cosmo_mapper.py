from antlr4 import *
from app.parser.CoSMoListener import CoSMoListener
from app.parser.CoSMoParser import CoSMoParser
from app.parser.CoSMoLexer import CoSMoLexer
from app.mapping.triple import Triple
from typing import List, Dict, Set, Tuple
from collections import defaultdict
from app.parser.preprocessor import CoSmoPreprocessor


class CoSMoToQueryMapper(CoSMoListener):
    def __init__(self, language: str = "en"):
        super().__init__()
        self.triples: List[Triple] = []
        self.cosmo_variable_mappings: Dict[str, str] = {}
        self.role_type_constraints: Dict[str, Dict[str, str]] = defaultdict(dict)
        self.type_replacements: Dict[str, str] = {}
        self.qitem_to_variable: Dict[str, str] = {}  # New dictionary for QItem to variable mapping
        self.variable_instantiations: Dict[str, str] = {}  # New dictionary
        self.current_instance: str = None
        self.joins: List[Tuple[str, str]] = []
        self.mandatory_fields: Set[str] = set()
        self.instantiated_type_constructors: Set[str] = set()
        self.language: str = language

    def enterInstanceConstructor(self, ctx:CoSMoParser.InstanceConstructorContext):
        instance_name = ctx.VARIABLE().getText()
        self.current_instance = instance_name

    def exitInstanceConstructor(self, ctx:CoSMoParser.InstanceConstructorContext):
        self.current_instance = None

    def enterPredicate(self, ctx:CoSMoParser.PredicateContext):
        p_item = ctx.PItem().getText()
        subject = ctx.VARIABLE(0).getText()
        object_var = ctx.VARIABLE(1).getText()
        object_qid = self.role_type_constraints[self.current_instance].get(object_var, f"?{object_var}")
        object_qid = self.type_replacements.get(object_qid, object_qid)
        triple = Triple(f"?{subject}", p_item, object_qid, self.current_instance)
        self.triples.append(triple)

    def enterRole(self, ctx:CoSMoParser.RoleContext):
        variable = ctx.VARIABLE(0).getText()
        object_type = ctx.QItem().getText()
        
        if self.current_instance:
            self.role_type_constraints[self.current_instance][variable] = f"wd:{object_type}"
        
        # Map QItem to variable name
        self.qitem_to_variable[object_type] = variable

    def enterInstantiation(self, ctx:CoSMoParser.InstantiationContext):
        object_type = ctx.QItem(0).getText()
        instance = ctx.QItem(1).getText()
        self.type_replacements[f"wd:{object_type}"] = f"wd:{instance}"
        
        # If this object_type was previously mapped to a variable, instantiate that variable
        if object_type in self.qitem_to_variable:
            variable = self.qitem_to_variable[object_type]
            self.variable_instantiations[variable] = f"wd:{instance}"

    def enterJoin(self, ctx:CoSMoParser.JoinContext):
        items = ctx.PItem() if ctx.PItem() else ctx.QItem()
        self.joins.append((items[0].getText(), items[1].getText()))

    def enterMandatory(self, ctx:CoSMoParser.MandatoryContext):
        mandatory_field = ctx.VARIABLE().getText()
        self.mandatory_fields.add(mandatory_field)

    def enterTypeConstructor(self, ctx:CoSMoParser.TypeConstructorContext):
        type_name = ctx.VARIABLE().getText()
        self.current_instance = type_name

    def exitTypeConstructor(self, ctx:CoSMoParser.TypeConstructorContext):
        self.current_instance = None

    def enterInstanceOf(self, ctx:CoSMoParser.InstanceOfContext):
        type_constructor = ctx.VARIABLE(1).getText()
        self.instantiated_type_constructors.add(type_constructor)

    def enterShortInstanceConstructor(self, ctx:CoSMoParser.ShortInstanceConstructorContext):
        instance_name = ctx.VARIABLE().getText()
        self.current_instance = instance_name

    def exitShortInstanceConstructor(self, ctx:CoSMoParser.ShortInstanceConstructorContext):
        self.current_instance = None

    def enterShortPredicate(self, ctx:CoSMoParser.ShortPredicateContext):
        p_item = ctx.PItem().getText()
        subject = ctx.VARIABLE(0).getText()
        object_var = ctx.VARIABLE(1).getText()
        object_qid = self.role_type_constraints[self.current_instance].get(object_var, f"?{object_var}")
        object_qid = self.type_replacements.get(object_qid, object_qid)
        triple = Triple(f"?{subject}", p_item, object_qid, self.current_instance)
        self.triples.append(triple)

    def enterShortRole(self, ctx:CoSMoParser.ShortRoleContext):
        variables = ctx.VARIABLE()
        object_type = ctx.QItem().getText()
        
        # Handle the case where there might be multiple variables
        for variable in variables:
            variable_text = variable.getText()
            
            if self.current_instance:
                self.role_type_constraints[self.current_instance][variable_text] = f"wd:{object_type}"
            
            # Map QItem to variable name
            self.qitem_to_variable[object_type] = variable_text

    def enterShortInstantiation(self, ctx:CoSMoParser.ShortInstantiationContext):
        object_type = ctx.QItem(0).getText()
        instance = ctx.QItem(1).getText()
        self.type_replacements[f"wd:{object_type}"] = f"wd:{instance}"
        
        # If this object_type was previously mapped to a variable, instantiate that variable
        if object_type in self.qitem_to_variable:
            variable = self.qitem_to_variable[object_type]
            self.variable_instantiations[variable] = f"wd:{instance}"

    def get_sparql_query(self) -> str:
        query = "SELECT ?entityId ?entity ?label WHERE {\n"

        # Process triples and joins
        join_groups = defaultdict(list)
        processed_triples = set()

        for triple in self.triples:
            subject = triple.subject
            predicate = f"wdt:{triple.predicate}"
            object_qid = triple.object

            # Check if the subject is a QItem that has been mapped to a variable
            if subject.lstrip('?') in self.variable_instantiations:
                subject = self.variable_instantiations[subject.lstrip('?')]
            else:
                subject = self.type_replacements.get(f"wd:{subject.lstrip('?')}", "?entity")

            # Check if the object is a QItem that has been mapped to a variable
            if object_qid.lstrip('?') in self.variable_instantiations:
                object_qid = self.variable_instantiations[object_qid.lstrip('?')]
            else:
                object_qid = self.type_replacements.get(f"wd:{object_qid.lstrip('?')}", "?entity")

            triple_str = f"  {subject} {predicate} {object_qid} .\n"
            if triple_str not in processed_triples:
                join_groups[triple.predicate].append(triple_str)
                processed_triples.add(triple_str)

        # Process joins
        if self.joins:
            query += "  {\n"
            for i, join in enumerate(self.joins):
                if i > 0:
                    query += "    UNION\n"
                query += "    {\n"
                for predicate in join:
                    if predicate in join_groups:
                        for triple in join_groups[predicate]:
                            query += "      " + triple
                        del join_groups[predicate]  # Remove processed predicates
                query += "    }\n"
            query += "  }\n"

        # Add remaining triples that are not part of any join
        for triples in join_groups.values():
            for triple in triples:
                query += triple

        # Add BIND statement for entityId
        query += "  BIND(STRAFTER(STR(?entity), \"http://www.wikidata.org/entity/\") AS ?entityId)\n"

        # Add label service with the specified language
        query += "  SERVICE wikibase:label {\n"
        query += f"    bd:serviceParam wikibase:language \"{self.language}, [AUTO_LANGUAGE]\" .\n"
        query += "    ?entity rdfs:label ?label .\n"
        query += "  }\n"

        # Add FILTER for mandatory fields
        for field in self.mandatory_fields:
            query += f"  FILTER(BOUND(?{field}))\n"

        query += "}"

        # Add LIMIT 100 for type constructors
        if self.current_instance not in self.instantiated_type_constructors:
            query += "\nLIMIT 100"

        return query

    def get_sql_query(self) -> str:
        select_clause = "SELECT DISTINCT e.id AS entity_id, m_e.label AS entity_label"
        from_clause = "FROM entity e"
        join_clause = "JOIN meta m_e ON e.id = m_e.id"
        where_clause = "WHERE "
        conditions = []

        for i, triple in enumerate(self.triples):
            property_id = triple.predicate.replace('P', '')
            join_clause += f"""
                JOIN string s{i} ON e.id = s{i}.id
                JOIN meta m_p{i} ON s{i}.property_id = m_p{i}.id"""
            select_clause += f", m_p{i}.label AS property_{i}_label, s{i}.string AS property_{i}_value"
            conditions.append(f"m_p{i}.id = {property_id}")
            conditions.append(f"s{i}.string = '{triple.object.replace('wd:', '')}'")

        for role, type_constraint in self.role_type_constraints[self.current_instance].items():
            actual_type = self.type_replacements.get(type_constraint, type_constraint)
            type_id = actual_type.replace('wd:', '')
            conditions.append(f"e.id = {type_id}")

        where_clause += " AND ".join(conditions)

        for field in self.mandatory_fields:
            where_clause += f" AND {field} IS NOT NULL"

        query = f"{select_clause}\n{from_clause}\n{join_clause}\n{where_clause};"
        return query

    def get_variable_instantiations(self) -> List[str]:
        """
        Returns a list of variable instantiation values.
        
        Returns:
            List[str]: A list of instantiation values.
        """
        return list(self.variable_instantiations.values())




if __name__ == "__main__":
    # Example CoSMo input
    cosmo_input = """
CSM006:C2(
P2283(r1,r2), r1:Q28640, r2:Q123588392, Q28640={Q154549})
    """

    # Preprocess the input
    preprocessor = CoSmoPreprocessor(language="en")
    preprocessed_input = preprocessor.preprocess(cosmo_input)


    # Create input stream
    input_stream = InputStream(preprocessed_input)
    
    # Create lexer
    lexer = CoSMoLexer(input_stream)
    
    # Create token stream
    token_stream = CommonTokenStream(lexer)
    
    # Create parser
    parser = CoSMoParser(token_stream)
    
    # Create parse tree
    parse_tree = parser.program()
    
    # Create and run mapper
    mapper = CoSMoToQueryMapper()
    walker = ParseTreeWalker()
    walker.walk(mapper, parse_tree)
    
    # Get SPARQL query
    sparql_query = mapper.get_sparql_query()
    print("SPARQL Query:")
    print(sparql_query)