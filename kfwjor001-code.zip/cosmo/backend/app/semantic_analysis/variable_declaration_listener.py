from antlr4 import *
from app.parser.CoSMoListener import CoSMoListener
from app.parser.CoSMoParser import CoSMoParser

class SemanticAnalysisListener(CoSMoListener):
    def __init__(self):
        super().__init__()
        self.variables = set()
        self.constructors = {}  # Stores both instance and type constructors
        self.instanceof_relations = {}  # Stores InstanceOf relations
        self.current_constructor = None
        self.errors = []
        self.instantiated_constructors = set()  # New set to track instantiated constructors

    def enterProgram(self, ctx:CoSMoParser.ProgramContext):
        self.variables.clear()
        self.constructors.clear()
        self.instanceof_relations.clear()
        self.current_constructor = None
        self.errors.clear()
        self.instantiated_constructors.clear()  # Clear instantiated constructors

    def check_declaration(self, variable_token, context_name):
        if variable_token:
            variable_name = variable_token.getText()
            if context_name in ["instance constructor", "type constructor"]:
                self.constructors[self.current_constructor].add(variable_name)
            elif variable_name in self.variables:
                self.errors.append(f"Error: Variable '{variable_name}' is already declared in {context_name}.")
            else:
                self.variables.add(variable_name)

    def check_usage(self, variable_token, context_name):
        if variable_token:
            variable_name = variable_token.getText()
            if variable_name not in self.variables and not any(variable_name in vars for vars in self.constructors.values()):
                self.errors.append(f"Error: Variable '{variable_name}' is used before declaration in {context_name}.")

    def enterInstanceConstructor(self, ctx:CoSMoParser.InstanceConstructorContext):
        constructor_name = ctx.VARIABLE().getText()
        self.instantiated_constructors.add(constructor_name)
        self.current_constructor = ctx.VARIABLE().getText()
        self.constructors[self.current_constructor] = set()

    def exitInstanceConstructor(self, ctx:CoSMoParser.InstanceConstructorContext):
        self.current_constructor = None

    def enterTypeConstructor(self, ctx:CoSMoParser.TypeConstructorContext):
        constructor_name = ctx.VARIABLE().getText()
        self.instantiated_constructors.add(constructor_name)
        self.current_constructor = ctx.VARIABLE().getText()
        self.constructors[self.current_constructor] = set()

    def exitTypeConstructor(self, ctx:CoSMoParser.TypeConstructorContext):
        constructor_name = ctx.VARIABLE().getText()
        if constructor_name in self.instanceof_relations:
            """
            instance_constructor = self.instanceof_relations[constructor_name]
            if instance_constructor in self.constructors:
                instance_vars = self.constructors[instance_constructor]
                type_vars = self.constructors[constructor_name]
                if type_vars != instance_vars:
                    missing_vars = instance_vars - type_vars
                    extra_vars = type_vars - instance_vars
                    if missing_vars:
                        self.errors.append(f"Error: Type constructor '{constructor_name}' is missing variables: {', '.join(missing_vars)}")
                    if extra_vars:
                        self.errors.append(f"Error: Type constructor '{constructor_name}' has extra variables: {', '.join(extra_vars)}")
            else:
                self.errors.append(f"Error: Instance constructor '{instance_constructor}' referenced in InstanceOf but not defined.")
                """
            pass
        else:
            self.errors.append(f"Error: Type constructor '{constructor_name}' is not associated with any instance constructor via InstanceOf.")
        self.current_constructor = None

    def check_constructor_instantiated(self, constructor_name, context):
        if constructor_name not in self.instantiated_constructors:
            self.errors.append(f"Error: Constructor '{constructor_name}' is used in {context} but not instantiated.")

    def enterInstanceOf(self, ctx:CoSMoParser.InstanceOfContext):
        if len(ctx.VARIABLE()) == 2:
            instance_constructor = ctx.VARIABLE()[0].getText()
            type_constructor = ctx.VARIABLE()[1].getText()
            self.check_constructor_instantiated(instance_constructor, "InstanceOf")
            self.check_constructor_instantiated(type_constructor, "InstanceOf")
            self.instanceof_relations[type_constructor] = instance_constructor
        else:
            self.errors.append("Error: InstanceOf must have exactly two variables.")

    def enterSubConstructorOf(self, ctx:CoSMoParser.SubConstructorOfContext):
        variables = ctx.VARIABLE()
        if len(variables) >= 2:
            for variable in variables:
                self.check_constructor_instantiated(variable.getText(), "SubConstructorOf")
            self.check_usage(variables[0], "subConstructorOf")
            self.check_usage(variables[1], "subConstructorOf")
        else:
            self.errors.append("Error: SubConstructorOf must have at least two variables.")

    def enterShortPartOf(self, ctx:CoSMoParser.ShortPartOfContext):
        variables = ctx.VARIABLE()
        if len(variables) >= 2:
            for variable in variables:
                self.check_constructor_instantiated(variable.getText(), "PartOf")
            self.check_usage(variables[0], "partOf")
            self.check_usage(variables[1], "partOf")
        else:
            self.errors.append("Error: ShortPartOf must have at least two variables.")

    def enterRole(self, ctx:CoSMoParser.RoleContext):
        pass

    def enterShortRole(self, ctx:CoSMoParser.ShortRoleContext):
        pass


    def enterArgument(self, ctx:CoSMoParser.ArgumentContext):
        pass

    def get_errors(self):
        return self.errors