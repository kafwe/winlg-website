import sys
import json
from SPARQLWrapper import SPARQLWrapper, JSON
from collections import OrderedDict
from datetime import datetime

# Hardcoded endpoint URL
ENDPOINT_URL = "https://query.wikidata.org/sparql"

def extract_id(url):
    return url.split('/')[-1]

def execute_sparql_query(query):
    user_agent = "WDQS-CoSMo Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    sparql = SPARQLWrapper(ENDPOINT_URL, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    return sparql.query().convert()

def clean_sparql_results(results):
    grouped_data = OrderedDict()

    for result in results["results"]["bindings"]:
        parent_qid = extract_id(result['parent']['value'])
        
        if parent_qid not in grouped_data:
            grouped_data[parent_qid] = {"label": result['parentLabel']['value'], "attributes": OrderedDict()}
        
        property_id = extract_id(result['property']['value'])
        value = extract_id(result['value']['value']) if result['value']['value'].startswith('http') else result['value']['value']
        
        if property_id not in grouped_data[parent_qid]["attributes"]:
            grouped_data[parent_qid]["attributes"][property_id] = []
        
        grouped_data[parent_qid]["attributes"][property_id].append({
            "label": result['propertyLabel']['value'],
            "value": value,
            "valueLabel": result['valueLabel']['value']
        })

    return dict(grouped_data)

def process_sparql_results(query):
    # Execute the query
    results = execute_sparql_query(query)
    return results


def expand_sparql_query(entities, language="en"):
    all_results = []
    for entity in entities:
        expanded_query = f"""
        SELECT ?parent ?parentLabel ?property ?propertyLabel ?value ?valueLabel ?sitelinks
        WHERE 
        {{
          BIND(wd:{entity} AS ?parent)
          ?parent ?property ?value .

          ?prop wikibase:directClaim ?property ;
                rdfs:label ?propertyLabel .
          FILTER(LANG(?propertyLabel) = "{language}")

          # Get the number of sitelinks for the value
          OPTIONAL {{ ?value wikibase:sitelinks ?sitelinks }}

          SERVICE wikibase:label {{
            bd:serviceParam wikibase:language "{language}, [AUTO_LANGUAGE]".
            ?parent rdfs:label ?parentLabel .
            ?value rdfs:label ?valueLabel .
            ?prop rdfs:label ?propertyLabel .
          }}
        }}
        ORDER BY DESC(?sitelinks)
        LIMIT 50
        """
        
        # Execute the query
        results = execute_sparql_query(expanded_query)
        all_results.extend(results["results"]["bindings"])

    # Clean all results
    cleaned_results = clean_sparql_results({"results": {"bindings": all_results}})

    return cleaned_results
    
    # Convert to JSON string
    json_results = json.dumps(cleaned_results, ensure_ascii=False, indent=2)
    


def test_print_expand_query_results():
    # Test entities
    test_entities = ["Q76"]  # Human and Barack Obama
    
    # Run the expand_sparql_query function
    results = expand_sparql_query(test_entities)
    
    # Print the results
    print("Expanded SPARQL Query Results:")
    print(results)

# Run the new test function
if __name__ == "__main__":
    test_print_expand_query_results()

