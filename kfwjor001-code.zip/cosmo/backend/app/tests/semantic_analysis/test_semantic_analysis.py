import pytest
from antlr4 import InputStream, CommonTokenStream, ParseTreeWalker
from app.parser.CoSMoLexer import CoSMoLexer
from app.parser.CoSMoParser import CoSMoParser
from app.semantic_analysis.variable_declaration_listener import SemanticAnalysisListener
from app.parser.preprocessor import CoSmoPreprocessor

def analyze_input(input_string, language="en"):
    preprocessor = CoSmoPreprocessor(language)
    preprocessed_input = preprocessor.preprocess(input_string)
    input_stream = InputStream(preprocessed_input)
    lexer = CoSMoLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = CoSMoParser(stream)
    tree = parser.program()

    listener = SemanticAnalysisListener()
    walker = ParseTreeWalker()
    walker.walk(listener, tree)

    return listener.get_errors()

@pytest.mark.parametrize("test_input,expected_errors,error_messages", [
    (
        """
        InstanceConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
        InstanceOf(C2, C1)
        TypeConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
        """,
        0,
        []
    ),
    (
        """
        InstanceConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
        InstanceOf(C2, C1)
        TypeConstructor:C1(Property(P40(r1,r3)), r1:ObjectType(Q7566), r3:ObjectType(Q29514218))
        """,
        2,
        ["missing variables: r2", "extra variables: r3"]
    ),
    (
        """
        InstanceConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
        TypeConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
        """,
        1,
        ["not associated with any instance constructor via InstanceOf"]
    ),
    (
        """
        InstanceOf(C2, C1)
        TypeConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
        """,
        1,
        ["Instance constructor 'C1' referenced in InstanceOf but not defined"]
    ),
])
def test_semantic_analysis(test_input, expected_errors, error_messages):
    errors = analyze_input(test_input)
    assert len(errors) == expected_errors, f"Expected {expected_errors} errors, but got: {len(errors)}"
    for message in error_messages:
        assert any(message in error for error in errors), f"Error message '{message}' not found in errors"

def test_valid_complex_input():
    complex_input = """
    InstanceConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
    InstanceOf(C2, C1)
    TypeConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
    InstanceConstructor:C2(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218), ObjectType(Q29514218)={Q62070381})
    SubConstructorOf(C3, C1)
    TypeConstructor:C3(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218), Function(Z12345(Q29514218)))
    """
    errors = analyze_input(complex_input)
    assert len(errors) == 0, f"Expected no errors, but got: {errors}"

def test_undeclared_variable():
    input_with_undeclared = """
    InstanceConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
    InstanceOf(C2, C1)
    TypeConstructor:C1(Property(P40(r1,r2)), r1:ObjectType(Q7566), r2:ObjectType(Q29514218))
    PartOf(UndeclaredVar, C1)
    """
    errors = analyze_input(input_with_undeclared)
    assert len(errors) == 1, f"Expected 1 error, but got: {len(errors)}"
    assert "UndeclaredVar" in errors[0], f"Error message doesn't mention UndeclaredVar: {errors[0]}"
