import pytest

from app.parser.preprocessor import CoSmoPreprocessor

def test_cosmo_preprocessor():
    # Original text
    original_text = """InstanceConstructor:C5(
    Property(P106(r1,r2)),
    r1:ObjectType(Q5),
    r2:ObjectType(Q18844224),
    Property(P136(r3,r4)),
    r3:ObjectType(Q18844224),
    r4:ObjectType(Q24925),
    ObjectType(Q5)={Q42})
    SubConstructorOf(C3, C1)"""

    # Create preprocessor
    preprocessor = CoSmoPreprocessor(language="en")

    # Test preprocessing
    processed_text = preprocessor.preprocess(original_text)
    assert "InstanceConstructor" not in processed_text
    assert "Property" not in processed_text
    assert "ObjectType" not in processed_text
    assert "SubConstructorOf" not in processed_text

    # Test postprocessing to different languages
    english_text = preprocessor.postprocess(processed_text, target_language="en")
    assert "InstanceConstructor" in english_text
    assert "Property" in english_text
    assert "ObjectType" in english_text
    assert "SubConstructorOf" in english_text

    spanish_text = preprocessor.postprocess(processed_text, target_language="es")
    assert "ConstructorDeInstancia" in spanish_text
    assert "Propiedad" in spanish_text
    assert "TipoDeEntidad" in spanish_text
    assert "SubConstructorDe" in spanish_text

    # Test postprocessing to Basque
    basque_text = preprocessor.postprocess(processed_text, target_language="eu")
    assert "Instantzia eraikitzaile" in basque_text
    assert "propietatea" in basque_text
    assert "izaki mota" in basque_text
    assert "honako berreraikitzaile" in basque_text
