from flask import Flask, request, jsonify
from antlr4 import *
from app.parser.CoSMoListener import CoSMoListener  
from app.parser.CoSMoParser import CoSMoParser
from app.parser.CoSMoLexer import CoSMoLexer
from app.parser.preprocessor import CoSmoPreprocessor
from app.mapping.cosmo_mapper import CoSMoToQueryMapper
from app.semantic_analysis.variable_declaration_listener import SemanticAnalysisListener 
from app.results.sparql_result_processor import execute_sparql_query, expand_sparql_query

app = Flask(__name__)

@app.route('/sparql', methods=['POST'])
def sparql():
    data = request.json
    cosmo_input = data.get('cosmo_statement')
    language = data.get('language', 'en')  # Default to 'en' if not provided

    if not cosmo_input:
        return jsonify({"error": "No CoSMo statement provided"}), 400

    cosmo_input = cosmo_input.strip()

    try:
        # Preprocess the input with the specified language
        preprocessor = CoSmoPreprocessor(language=language)
        preprocessed_input = preprocessor.preprocess(cosmo_input)

        # Create input stream
        input_stream = InputStream(preprocessed_input)
        
        # Create lexer
        lexer = CoSMoLexer(input_stream)
        
        # Create token stream
        token_stream = CommonTokenStream(lexer)
        
        # Create parser
        parser = CoSMoParser(token_stream)
        semantic_analysis_listener = SemanticAnalysisListener()
        parse_tree = parser.program()
        
        # Create and run mapper
        mapper = CoSMoToQueryMapper(language=language)
        walker = ParseTreeWalker()
        #semantic_analysis_errors = semantic_analysis_listener.get_errors()

        #if semantic_analysis_errors:
        #    return jsonify({"error": semantic_analysis_errors}), 400
        
        walker.walk(mapper, parse_tree)
        
        # Get SPARQL query
        sparql_query = mapper.get_sparql_query()
        print(sparql_query)
        entity_of_interest = mapper.get_variable_instantiations()
        
        for i in range(len(entity_of_interest)):
            entity_of_interest[i] = entity_of_interest[i].lstrip('wd:')

        query_result = execute_sparql_query(sparql_query)

        expanded_query = expand_sparql_query(entity_of_interest, language=language)



        return jsonify({
            "actual_query": query_result,
            "expanded_query": expanded_query,
            "language": language  # Include the used language in the response
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)