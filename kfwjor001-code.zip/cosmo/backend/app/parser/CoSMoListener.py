# Generated from CoSMo.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .CoSMoParser import CoSMoParser
else:
    from CoSMoParser import CoSMoParser

# This class defines a complete listener for a parse tree produced by CoSMoParser.
class CoSMoListener(ParseTreeListener):

    # Enter a parse tree produced by CoSMoParser#program.
    def enterProgram(self, ctx:CoSMoParser.ProgramContext):
        pass

    # Exit a parse tree produced by CoSMoParser#program.
    def exitProgram(self, ctx:CoSMoParser.ProgramContext):
        pass


    # Enter a parse tree produced by CoSMoParser#declaration.
    def enterDeclaration(self, ctx:CoSMoParser.DeclarationContext):
        pass

    # Exit a parse tree produced by CoSMoParser#declaration.
    def exitDeclaration(self, ctx:CoSMoParser.DeclarationContext):
        pass


    # Enter a parse tree produced by CoSMoParser#longFormDeclaration.
    def enterLongFormDeclaration(self, ctx:CoSMoParser.LongFormDeclarationContext):
        pass

    # Exit a parse tree produced by CoSMoParser#longFormDeclaration.
    def exitLongFormDeclaration(self, ctx:CoSMoParser.LongFormDeclarationContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortFormDeclaration.
    def enterShortFormDeclaration(self, ctx:CoSMoParser.ShortFormDeclarationContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortFormDeclaration.
    def exitShortFormDeclaration(self, ctx:CoSMoParser.ShortFormDeclarationContext):
        pass


    # Enter a parse tree produced by CoSMoParser#typeConstructor.
    def enterTypeConstructor(self, ctx:CoSMoParser.TypeConstructorContext):
        pass

    # Exit a parse tree produced by CoSMoParser#typeConstructor.
    def exitTypeConstructor(self, ctx:CoSMoParser.TypeConstructorContext):
        pass


    # Enter a parse tree produced by CoSMoParser#instanceConstructor.
    def enterInstanceConstructor(self, ctx:CoSMoParser.InstanceConstructorContext):
        pass

    # Exit a parse tree produced by CoSMoParser#instanceConstructor.
    def exitInstanceConstructor(self, ctx:CoSMoParser.InstanceConstructorContext):
        pass


    # Enter a parse tree produced by CoSMoParser#instanceOf.
    def enterInstanceOf(self, ctx:CoSMoParser.InstanceOfContext):
        pass

    # Exit a parse tree produced by CoSMoParser#instanceOf.
    def exitInstanceOf(self, ctx:CoSMoParser.InstanceOfContext):
        pass


    # Enter a parse tree produced by CoSMoParser#subConstructorOf.
    def enterSubConstructorOf(self, ctx:CoSMoParser.SubConstructorOfContext):
        pass

    # Exit a parse tree produced by CoSMoParser#subConstructorOf.
    def exitSubConstructorOf(self, ctx:CoSMoParser.SubConstructorOfContext):
        pass


    # Enter a parse tree produced by CoSMoParser#typeDefinition.
    def enterTypeDefinition(self, ctx:CoSMoParser.TypeDefinitionContext):
        pass

    # Exit a parse tree produced by CoSMoParser#typeDefinition.
    def exitTypeDefinition(self, ctx:CoSMoParser.TypeDefinitionContext):
        pass


    # Enter a parse tree produced by CoSMoParser#instDefinition.
    def enterInstDefinition(self, ctx:CoSMoParser.InstDefinitionContext):
        pass

    # Exit a parse tree produced by CoSMoParser#instDefinition.
    def exitInstDefinition(self, ctx:CoSMoParser.InstDefinitionContext):
        pass


    # Enter a parse tree produced by CoSMoParser#predicate.
    def enterPredicate(self, ctx:CoSMoParser.PredicateContext):
        pass

    # Exit a parse tree produced by CoSMoParser#predicate.
    def exitPredicate(self, ctx:CoSMoParser.PredicateContext):
        pass


    # Enter a parse tree produced by CoSMoParser#role.
    def enterRole(self, ctx:CoSMoParser.RoleContext):
        pass

    # Exit a parse tree produced by CoSMoParser#role.
    def exitRole(self, ctx:CoSMoParser.RoleContext):
        pass


    # Enter a parse tree produced by CoSMoParser#function.
    def enterFunction(self, ctx:CoSMoParser.FunctionContext):
        pass

    # Exit a parse tree produced by CoSMoParser#function.
    def exitFunction(self, ctx:CoSMoParser.FunctionContext):
        pass


    # Enter a parse tree produced by CoSMoParser#instantiation.
    def enterInstantiation(self, ctx:CoSMoParser.InstantiationContext):
        pass

    # Exit a parse tree produced by CoSMoParser#instantiation.
    def exitInstantiation(self, ctx:CoSMoParser.InstantiationContext):
        pass


    # Enter a parse tree produced by CoSMoParser#join.
    def enterJoin(self, ctx:CoSMoParser.JoinContext):
        pass

    # Exit a parse tree produced by CoSMoParser#join.
    def exitJoin(self, ctx:CoSMoParser.JoinContext):
        pass


    # Enter a parse tree produced by CoSMoParser#mandatory.
    def enterMandatory(self, ctx:CoSMoParser.MandatoryContext):
        pass

    # Exit a parse tree produced by CoSMoParser#mandatory.
    def exitMandatory(self, ctx:CoSMoParser.MandatoryContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortTypeConstructor.
    def enterShortTypeConstructor(self, ctx:CoSMoParser.ShortTypeConstructorContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortTypeConstructor.
    def exitShortTypeConstructor(self, ctx:CoSMoParser.ShortTypeConstructorContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortInstanceConstructor.
    def enterShortInstanceConstructor(self, ctx:CoSMoParser.ShortInstanceConstructorContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortInstanceConstructor.
    def exitShortInstanceConstructor(self, ctx:CoSMoParser.ShortInstanceConstructorContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortInstanceOf.
    def enterShortInstanceOf(self, ctx:CoSMoParser.ShortInstanceOfContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortInstanceOf.
    def exitShortInstanceOf(self, ctx:CoSMoParser.ShortInstanceOfContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortSubConstructorOf.
    def enterShortSubConstructorOf(self, ctx:CoSMoParser.ShortSubConstructorOfContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortSubConstructorOf.
    def exitShortSubConstructorOf(self, ctx:CoSMoParser.ShortSubConstructorOfContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortPartOf.
    def enterShortPartOf(self, ctx:CoSMoParser.ShortPartOfContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortPartOf.
    def exitShortPartOf(self, ctx:CoSMoParser.ShortPartOfContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortTypeDefinition.
    def enterShortTypeDefinition(self, ctx:CoSMoParser.ShortTypeDefinitionContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortTypeDefinition.
    def exitShortTypeDefinition(self, ctx:CoSMoParser.ShortTypeDefinitionContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortInstDefinition.
    def enterShortInstDefinition(self, ctx:CoSMoParser.ShortInstDefinitionContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortInstDefinition.
    def exitShortInstDefinition(self, ctx:CoSMoParser.ShortInstDefinitionContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortPredicate.
    def enterShortPredicate(self, ctx:CoSMoParser.ShortPredicateContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortPredicate.
    def exitShortPredicate(self, ctx:CoSMoParser.ShortPredicateContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortRole.
    def enterShortRole(self, ctx:CoSMoParser.ShortRoleContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortRole.
    def exitShortRole(self, ctx:CoSMoParser.ShortRoleContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortFunction.
    def enterShortFunction(self, ctx:CoSMoParser.ShortFunctionContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortFunction.
    def exitShortFunction(self, ctx:CoSMoParser.ShortFunctionContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortJoin.
    def enterShortJoin(self, ctx:CoSMoParser.ShortJoinContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortJoin.
    def exitShortJoin(self, ctx:CoSMoParser.ShortJoinContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortMandatory.
    def enterShortMandatory(self, ctx:CoSMoParser.ShortMandatoryContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortMandatory.
    def exitShortMandatory(self, ctx:CoSMoParser.ShortMandatoryContext):
        pass


    # Enter a parse tree produced by CoSMoParser#shortInstantiation.
    def enterShortInstantiation(self, ctx:CoSMoParser.ShortInstantiationContext):
        pass

    # Exit a parse tree produced by CoSMoParser#shortInstantiation.
    def exitShortInstantiation(self, ctx:CoSMoParser.ShortInstantiationContext):
        pass


    # Enter a parse tree produced by CoSMoParser#valueConstraint.
    def enterValueConstraint(self, ctx:CoSMoParser.ValueConstraintContext):
        pass

    # Exit a parse tree produced by CoSMoParser#valueConstraint.
    def exitValueConstraint(self, ctx:CoSMoParser.ValueConstraintContext):
        pass


    # Enter a parse tree produced by CoSMoParser#argumentList.
    def enterArgumentList(self, ctx:CoSMoParser.ArgumentListContext):
        pass

    # Exit a parse tree produced by CoSMoParser#argumentList.
    def exitArgumentList(self, ctx:CoSMoParser.ArgumentListContext):
        pass


    # Enter a parse tree produced by CoSMoParser#argument.
    def enterArgument(self, ctx:CoSMoParser.ArgumentContext):
        pass

    # Exit a parse tree produced by CoSMoParser#argument.
    def exitArgument(self, ctx:CoSMoParser.ArgumentContext):
        pass



del CoSMoParser