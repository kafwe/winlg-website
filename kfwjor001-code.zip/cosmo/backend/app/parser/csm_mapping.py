CSM_MAPPING = {
    "Object": "CSM001",
    "ObjectType": "CSM002",
    "Property": "CSM003",
    "Role": "CSM004",
    "Function": "CSM005",
    "InstanceConstructor": "CSM006",
    "TypeConstructor": "CSM007",
    "SubConstructorOf": "CSM008",
    "InstanceOf": "CSM009",
    "PartOf": "CSM010",
    "Join": "CSM011",
    "IsMandatory": "CSM012",
    "Name": "CSM013",
    "ValueConstraint": "CSM014"
}

LANGUAGE_MAPPINGS = {
    "en": {
        "Object": "CSM001",
        "ObjectType": "CSM002",
        "Property": "CSM003",
        "Role": "CSM004",
        "Function": "CSM005",
        "InstanceConstructor": "CSM006",
        "TypeConstructor": "CSM007",
        "SubConstructorOf": "CSM008",
        "InstanceOf": "CSM009",
        "PartOf": "CSM010",
        "Join": "CSM011",
        "IsMandatory": "CSM012",
        "Name": "CSM013",
        "Value constraint": "CSM014"
    },
    "es": {
        "Entidad": "CSM001",
        "TipoDeEntidad": "CSM002",
        "Propiedad": "CSM003",
        "Rol": "CSM004",
        "Función": "CSM005",
        "ConstructorDeInstancia": "CSM006",
        "ConstructorDeTipo": "CSM007",
        "SubConstructorDe": "CSM008",
        "InstanciaDe": "CSM009",
        "ParteDe": "CSM010",
        "Unión": "CSM011",
        "EsObligatorio": "CSM012",
        "Nombre": "CSM013",
        "RestricciónDeValor": "CSM014"
    },
    "eu": {
        "Izaki": "CSM001",
        "izaki mota": "CSM002",
        "propietatea": "CSM003",
        "Rol": "CSM004",
        "Funtzio": "CSM005",
        "Instantzia eraikitzaile": "CSM006",
        "tipo eraikitzaile": "CSM007",
        "honako berreraikitzaile": "CSM008",
        "honako hau da": "CSM009",
        "Osatuta": "CSM010",
        "bildura": "CSM011",
        "nahitaezko": "CSM012",
        "Izen": "CSM013",
        "balio murrizte": "CSM014"
    }
}
