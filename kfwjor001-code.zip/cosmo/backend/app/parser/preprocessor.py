from .csm_mapping import CSM_MAPPING, LANGUAGE_MAPPINGS
import re

class CoSmoPreprocessor:
    def __init__(self, language="en"):
        self.language = language
        self.mapping = {**CSM_MAPPING, **LANGUAGE_MAPPINGS.get(language, {})}
        self.reverse_mapping = {v: k for k, v in self.mapping.items()}

    def preprocess(self, input_string: str) -> str:
        """
        Preprocess the input string by replacing language-specific terms with CSM IDs.
        """
        # Sort the mapping keys by length in descending order to handle longer phrases first
        sorted_terms = sorted(self.mapping.keys(), key=len, reverse=True)
        
        for term in sorted_terms:
            pattern = r'\b' + re.escape(term) + r'\b'
            input_string = re.sub(pattern, self.mapping[term], input_string, flags=re.IGNORECASE)
        
        return input_string

    def postprocess(self, processed_string: str, target_language: str = None) -> str:
        """
        Postprocess the string by replacing CSM IDs with the original terms in the specified target language.
        If no target language is specified, use the initial language.
        """
        target_language = target_language or self.language
        # if target language is not in LANGUAGE_MAPPINGS, use the initial language
        if target_language not in LANGUAGE_MAPPINGS:
            target_language = "en"

        target_mapping = LANGUAGE_MAPPINGS.get(target_language, {})
        
        for csm_id in CSM_MAPPING.values():
            if csm_id in processed_string:
                term = None
                for k, v in target_mapping.items():
                    if v == csm_id:
                        term = k
                        break
                
                if term is None:
                    for k, v in CSM_MAPPING.items():
                        if v == csm_id:
                            term = k
                            break
                
                if term:
                    processed_string = processed_string.replace(csm_id, term)
        
        return processed_string

    def _tokenize(self, input_string: str) -> list:
        """
        Tokenize the input string into words and punctuation.
        """
        return re.findall(r'\b\w+\b|[^\w\s]', input_string)

    def preprocess_tokens(self, input_string: str) -> list:
        """
        Preprocess the input string and return a list of tokens with CSM IDs.
        """
        preprocessed = self.preprocess(input_string)
        return self._tokenize(preprocessed)

    def get_csm_id(self, term: str) -> str:
        """
        Get the CSM ID for a given term, if it exists in the mapping.
        """
        return self.mapping.get(term, term)

    def get_term(self, csm_id: str) -> str:
        """
        Get the original term (in English) for a given CSM ID, if it exists in the reverse mapping.
        """
        return self.reverse_mapping.get(csm_id, csm_id)

# Add this at the end of the file
if __name__ == "__main__":
    # Original text
    original_text = """InstanceConstructor:C5(
    Property(P106(r1,r2)),
    r1:ObjectType(Q5),
    r2:ObjectType(Q18844224),
    Property(P136(r3,r4)),
    r3:ObjectType(Q18844224),
    r4:ObjectType(Q24925),
    ObjectType(Q5)={Q42})
    SubConstructorOf(C3, C1)"""

    # Create preprocessor
    preprocessor = CoSmoPreprocessor(language="en")

    # Preprocess
    processed_text = preprocessor.preprocess(original_text)
    print("Processed text:")
    print(processed_text)
    print()

    # Postprocess to different languages
    print("Postprocessed to English:")
    print(preprocessor.postprocess(processed_text, target_language="en"))
    print()

    print("Postprocessed to Spanish:")
    print(preprocessor.postprocess(processed_text, target_language="es"))
    print()

    print("Postprocessed to Basque:")
    print(preprocessor.postprocess(processed_text, target_language="eu"))
