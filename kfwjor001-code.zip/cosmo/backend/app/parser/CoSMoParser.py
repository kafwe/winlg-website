# Generated from CoSMo.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,31,378,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,1,0,4,0,66,8,0,
        11,0,12,0,67,1,1,1,1,3,1,72,8,1,1,2,1,2,1,2,1,2,3,2,78,8,2,1,3,1,
        3,1,3,1,3,1,3,3,3,85,8,3,1,4,1,4,1,4,1,4,1,4,4,4,92,8,4,11,4,12,
        4,93,1,4,1,4,3,4,98,8,4,1,5,1,5,1,5,1,5,1,5,4,5,105,8,5,11,5,12,
        5,106,1,5,1,5,3,5,111,8,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,3,6,120,8,
        6,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,129,8,7,1,8,1,8,3,8,133,8,8,1,
        8,1,8,3,8,137,8,8,1,8,3,8,140,8,8,1,8,1,8,3,8,144,8,8,1,8,1,8,3,
        8,148,8,8,1,8,1,8,3,8,152,8,8,1,8,1,8,3,8,156,8,8,3,8,158,8,8,1,
        9,1,9,3,9,162,8,9,1,9,1,9,3,9,166,8,9,1,9,3,9,169,8,9,1,9,1,9,3,
        9,173,8,9,1,9,1,9,3,9,177,8,9,1,9,1,9,3,9,181,8,9,3,9,183,8,9,1,
        10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,11,1,11,1,11,1,
        11,3,11,199,8,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,3,
        11,210,8,11,1,12,1,12,1,12,1,12,1,12,3,12,217,8,12,1,12,1,12,1,12,
        1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,14,1,14,1,14,1,14,
        1,14,1,14,1,14,1,14,1,14,3,14,240,8,14,1,14,1,14,1,14,1,15,1,15,
        1,15,1,15,1,15,1,16,1,16,1,16,1,16,1,16,4,16,255,8,16,11,16,12,16,
        256,1,16,1,16,1,17,1,17,1,17,1,17,1,17,4,17,266,8,17,11,17,12,17,
        267,1,17,1,17,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,19,1,19,1,19,
        1,19,1,19,1,19,1,19,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,21,1,21,
        1,21,1,21,1,21,1,21,1,21,3,21,300,8,21,1,22,1,22,1,22,1,22,1,22,
        1,22,3,22,308,8,22,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,24,1,24,
        1,24,1,24,3,24,321,8,24,1,24,1,24,1,24,1,24,1,24,1,24,3,24,329,8,
        24,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,339,8,25,1,26,1,
        26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,3,26,350,8,26,1,26,1,26,1,
        26,1,27,1,27,1,27,1,27,1,27,1,28,1,28,1,28,1,28,1,28,1,28,1,29,1,
        29,1,30,1,30,1,30,5,30,371,8,30,10,30,12,30,374,9,30,1,31,1,31,1,
        31,0,0,32,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,
        40,42,44,46,48,50,52,54,56,58,60,62,0,2,1,0,12,13,3,0,9,11,26,26,
        29,30,404,0,65,1,0,0,0,2,71,1,0,0,0,4,77,1,0,0,0,6,84,1,0,0,0,8,
        86,1,0,0,0,10,99,1,0,0,0,12,112,1,0,0,0,14,121,1,0,0,0,16,157,1,
        0,0,0,18,182,1,0,0,0,20,184,1,0,0,0,22,194,1,0,0,0,24,211,1,0,0,
        0,26,221,1,0,0,0,28,230,1,0,0,0,30,244,1,0,0,0,32,249,1,0,0,0,34,
        260,1,0,0,0,36,271,1,0,0,0,38,278,1,0,0,0,40,285,1,0,0,0,42,299,
        1,0,0,0,44,307,1,0,0,0,46,309,1,0,0,0,48,316,1,0,0,0,50,330,1,0,
        0,0,52,340,1,0,0,0,54,354,1,0,0,0,56,359,1,0,0,0,58,365,1,0,0,0,
        60,367,1,0,0,0,62,375,1,0,0,0,64,66,3,2,1,0,65,64,1,0,0,0,66,67,
        1,0,0,0,67,65,1,0,0,0,67,68,1,0,0,0,68,1,1,0,0,0,69,72,3,4,2,0,70,
        72,3,6,3,0,71,69,1,0,0,0,71,70,1,0,0,0,72,3,1,0,0,0,73,78,3,8,4,
        0,74,78,3,10,5,0,75,78,3,12,6,0,76,78,3,14,7,0,77,73,1,0,0,0,77,
        74,1,0,0,0,77,75,1,0,0,0,77,76,1,0,0,0,78,5,1,0,0,0,79,85,3,32,16,
        0,80,85,3,34,17,0,81,85,3,36,18,0,82,85,3,38,19,0,83,85,3,40,20,
        0,84,79,1,0,0,0,84,80,1,0,0,0,84,81,1,0,0,0,84,82,1,0,0,0,84,83,
        1,0,0,0,85,7,1,0,0,0,86,87,5,18,0,0,87,88,5,1,0,0,88,89,5,26,0,0,
        89,91,5,2,0,0,90,92,3,16,8,0,91,90,1,0,0,0,92,93,1,0,0,0,93,91,1,
        0,0,0,93,94,1,0,0,0,94,95,1,0,0,0,95,97,5,3,0,0,96,98,5,28,0,0,97,
        96,1,0,0,0,97,98,1,0,0,0,98,9,1,0,0,0,99,100,5,17,0,0,100,101,5,
        1,0,0,101,102,5,26,0,0,102,104,5,2,0,0,103,105,3,18,9,0,104,103,
        1,0,0,0,105,106,1,0,0,0,106,104,1,0,0,0,106,107,1,0,0,0,107,108,
        1,0,0,0,108,110,5,3,0,0,109,111,5,28,0,0,110,109,1,0,0,0,110,111,
        1,0,0,0,111,11,1,0,0,0,112,113,5,20,0,0,113,114,5,2,0,0,114,115,
        5,26,0,0,115,116,5,28,0,0,116,117,5,26,0,0,117,119,5,3,0,0,118,120,
        5,28,0,0,119,118,1,0,0,0,119,120,1,0,0,0,120,13,1,0,0,0,121,122,
        5,19,0,0,122,123,5,2,0,0,123,124,5,26,0,0,124,125,5,28,0,0,125,126,
        5,26,0,0,126,128,5,3,0,0,127,129,5,28,0,0,128,127,1,0,0,0,128,129,
        1,0,0,0,129,15,1,0,0,0,130,132,3,20,10,0,131,133,5,28,0,0,132,131,
        1,0,0,0,132,133,1,0,0,0,133,158,1,0,0,0,134,137,3,22,11,0,135,137,
        3,48,24,0,136,134,1,0,0,0,136,135,1,0,0,0,137,139,1,0,0,0,138,140,
        5,28,0,0,139,138,1,0,0,0,139,140,1,0,0,0,140,158,1,0,0,0,141,143,
        3,24,12,0,142,144,5,28,0,0,143,142,1,0,0,0,143,144,1,0,0,0,144,158,
        1,0,0,0,145,147,3,26,13,0,146,148,5,28,0,0,147,146,1,0,0,0,147,148,
        1,0,0,0,148,158,1,0,0,0,149,151,3,28,14,0,150,152,5,28,0,0,151,150,
        1,0,0,0,151,152,1,0,0,0,152,158,1,0,0,0,153,155,3,30,15,0,154,156,
        5,28,0,0,155,154,1,0,0,0,155,156,1,0,0,0,156,158,1,0,0,0,157,130,
        1,0,0,0,157,136,1,0,0,0,157,141,1,0,0,0,157,145,1,0,0,0,157,149,
        1,0,0,0,157,153,1,0,0,0,158,17,1,0,0,0,159,161,3,20,10,0,160,162,
        5,28,0,0,161,160,1,0,0,0,161,162,1,0,0,0,162,183,1,0,0,0,163,166,
        3,22,11,0,164,166,3,48,24,0,165,163,1,0,0,0,165,164,1,0,0,0,166,
        168,1,0,0,0,167,169,5,28,0,0,168,167,1,0,0,0,168,169,1,0,0,0,169,
        183,1,0,0,0,170,172,3,26,13,0,171,173,5,28,0,0,172,171,1,0,0,0,172,
        173,1,0,0,0,173,183,1,0,0,0,174,176,3,28,14,0,175,177,5,28,0,0,176,
        175,1,0,0,0,176,177,1,0,0,0,177,183,1,0,0,0,178,180,3,30,15,0,179,
        181,5,28,0,0,180,179,1,0,0,0,180,181,1,0,0,0,181,183,1,0,0,0,182,
        159,1,0,0,0,182,165,1,0,0,0,182,170,1,0,0,0,182,174,1,0,0,0,182,
        178,1,0,0,0,183,19,1,0,0,0,184,185,5,14,0,0,185,186,5,2,0,0,186,
        187,5,9,0,0,187,188,5,2,0,0,188,189,5,26,0,0,189,190,5,28,0,0,190,
        191,5,26,0,0,191,192,5,3,0,0,192,193,5,3,0,0,193,21,1,0,0,0,194,
        198,5,26,0,0,195,196,5,4,0,0,196,197,5,26,0,0,197,199,5,5,0,0,198,
        195,1,0,0,0,198,199,1,0,0,0,199,200,1,0,0,0,200,201,5,1,0,0,201,
        202,7,0,0,0,202,203,5,2,0,0,203,204,5,10,0,0,204,209,5,3,0,0,205,
        206,5,6,0,0,206,207,3,58,29,0,207,208,5,7,0,0,208,210,1,0,0,0,209,
        205,1,0,0,0,209,210,1,0,0,0,210,23,1,0,0,0,211,212,5,16,0,0,212,
        213,5,2,0,0,213,214,5,11,0,0,214,216,5,2,0,0,215,217,3,60,30,0,216,
        215,1,0,0,0,216,217,1,0,0,0,217,218,1,0,0,0,218,219,5,3,0,0,219,
        220,5,3,0,0,220,25,1,0,0,0,221,222,5,13,0,0,222,223,5,2,0,0,223,
        224,5,10,0,0,224,225,5,3,0,0,225,226,5,8,0,0,226,227,5,6,0,0,227,
        228,5,10,0,0,228,229,5,7,0,0,229,27,1,0,0,0,230,231,5,22,0,0,231,
        232,5,2,0,0,232,239,5,2,0,0,233,234,5,9,0,0,234,235,5,28,0,0,235,
        240,5,9,0,0,236,237,5,10,0,0,237,238,5,28,0,0,238,240,5,10,0,0,239,
        233,1,0,0,0,239,236,1,0,0,0,240,241,1,0,0,0,241,242,5,3,0,0,242,
        243,5,3,0,0,243,29,1,0,0,0,244,245,5,23,0,0,245,246,5,2,0,0,246,
        247,5,26,0,0,247,248,5,3,0,0,248,31,1,0,0,0,249,250,5,18,0,0,250,
        251,5,1,0,0,251,252,5,26,0,0,252,254,5,2,0,0,253,255,3,42,21,0,254,
        253,1,0,0,0,255,256,1,0,0,0,256,254,1,0,0,0,256,257,1,0,0,0,257,
        258,1,0,0,0,258,259,5,3,0,0,259,33,1,0,0,0,260,261,5,17,0,0,261,
        262,5,1,0,0,262,263,5,26,0,0,263,265,5,2,0,0,264,266,3,44,22,0,265,
        264,1,0,0,0,266,267,1,0,0,0,267,265,1,0,0,0,267,268,1,0,0,0,268,
        269,1,0,0,0,269,270,5,3,0,0,270,35,1,0,0,0,271,272,5,20,0,0,272,
        273,5,2,0,0,273,274,5,26,0,0,274,275,5,28,0,0,275,276,5,26,0,0,276,
        277,5,3,0,0,277,37,1,0,0,0,278,279,5,19,0,0,279,280,5,2,0,0,280,
        281,5,26,0,0,281,282,5,28,0,0,282,283,5,26,0,0,283,284,5,3,0,0,284,
        39,1,0,0,0,285,286,5,21,0,0,286,287,5,2,0,0,287,288,5,26,0,0,288,
        289,5,28,0,0,289,290,5,26,0,0,290,291,5,3,0,0,291,41,1,0,0,0,292,
        300,3,46,23,0,293,300,3,48,24,0,294,300,3,50,25,0,295,300,3,56,28,
        0,296,300,3,52,26,0,297,300,3,54,27,0,298,300,5,28,0,0,299,292,1,
        0,0,0,299,293,1,0,0,0,299,294,1,0,0,0,299,295,1,0,0,0,299,296,1,
        0,0,0,299,297,1,0,0,0,299,298,1,0,0,0,300,43,1,0,0,0,301,308,3,46,
        23,0,302,308,3,48,24,0,303,308,3,56,28,0,304,308,3,52,26,0,305,308,
        3,54,27,0,306,308,5,28,0,0,307,301,1,0,0,0,307,302,1,0,0,0,307,303,
        1,0,0,0,307,304,1,0,0,0,307,305,1,0,0,0,307,306,1,0,0,0,308,45,1,
        0,0,0,309,310,5,9,0,0,310,311,5,2,0,0,311,312,5,26,0,0,312,313,5,
        28,0,0,313,314,5,26,0,0,314,315,5,3,0,0,315,47,1,0,0,0,316,320,5,
        26,0,0,317,318,5,4,0,0,318,319,5,26,0,0,319,321,5,5,0,0,320,317,
        1,0,0,0,320,321,1,0,0,0,321,322,1,0,0,0,322,323,5,1,0,0,323,328,
        5,10,0,0,324,325,5,6,0,0,325,326,3,58,29,0,326,327,5,7,0,0,327,329,
        1,0,0,0,328,324,1,0,0,0,328,329,1,0,0,0,329,49,1,0,0,0,330,331,5,
        11,0,0,331,332,5,2,0,0,332,333,3,60,30,0,333,338,5,3,0,0,334,335,
        5,6,0,0,335,336,3,58,29,0,336,337,5,7,0,0,337,339,1,0,0,0,338,334,
        1,0,0,0,338,339,1,0,0,0,339,51,1,0,0,0,340,341,5,22,0,0,341,342,
        5,2,0,0,342,349,5,2,0,0,343,344,5,9,0,0,344,345,5,28,0,0,345,350,
        5,9,0,0,346,347,5,10,0,0,347,348,5,28,0,0,348,350,5,10,0,0,349,343,
        1,0,0,0,349,346,1,0,0,0,350,351,1,0,0,0,351,352,5,3,0,0,352,353,
        5,3,0,0,353,53,1,0,0,0,354,355,5,23,0,0,355,356,5,2,0,0,356,357,
        5,26,0,0,357,358,5,3,0,0,358,55,1,0,0,0,359,360,5,10,0,0,360,361,
        5,8,0,0,361,362,5,6,0,0,362,363,5,10,0,0,363,364,5,7,0,0,364,57,
        1,0,0,0,365,366,5,25,0,0,366,59,1,0,0,0,367,372,3,62,31,0,368,369,
        5,28,0,0,369,371,3,62,31,0,370,368,1,0,0,0,371,374,1,0,0,0,372,370,
        1,0,0,0,372,373,1,0,0,0,373,61,1,0,0,0,374,372,1,0,0,0,375,376,7,
        1,0,0,376,63,1,0,0,0,38,67,71,77,84,93,97,106,110,119,128,132,136,
        139,143,147,151,155,157,161,165,168,172,176,180,182,198,209,216,
        239,256,267,299,307,320,328,338,349,372
    ]

class CoSMoParser ( Parser ):

    grammarFileName = "CoSMo.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "':'", "'('", "')'", "'['", "']'", "'{'", 
                     "'}'", "'='", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'CSM001'", "'CSM002'", "'CSM003'", "'CSM004'", "'CSM005'", 
                     "'CSM006'", "'CSM007'", "'CSM008'", "'CSM009'", "'CSM010'", 
                     "'CSM011'", "'CSM012'", "'CSM013'", "'CSM014'", "<INVALID>", 
                     "<INVALID>", "','" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "PItem", "QItem", "ZItem", "CSM001", 
                      "CSM002", "CSM003", "CSM004", "CSM005", "CSM006", 
                      "CSM007", "CSM008", "CSM009", "CSM010", "CSM011", 
                      "CSM012", "CSM013", "CSM014", "VARIABLE", "DIGIT", 
                      "COMMA", "NUMBER", "STRING", "WS" ]

    RULE_program = 0
    RULE_declaration = 1
    RULE_longFormDeclaration = 2
    RULE_shortFormDeclaration = 3
    RULE_typeConstructor = 4
    RULE_instanceConstructor = 5
    RULE_instanceOf = 6
    RULE_subConstructorOf = 7
    RULE_typeDefinition = 8
    RULE_instDefinition = 9
    RULE_predicate = 10
    RULE_role = 11
    RULE_function = 12
    RULE_instantiation = 13
    RULE_join = 14
    RULE_mandatory = 15
    RULE_shortTypeConstructor = 16
    RULE_shortInstanceConstructor = 17
    RULE_shortInstanceOf = 18
    RULE_shortSubConstructorOf = 19
    RULE_shortPartOf = 20
    RULE_shortTypeDefinition = 21
    RULE_shortInstDefinition = 22
    RULE_shortPredicate = 23
    RULE_shortRole = 24
    RULE_shortFunction = 25
    RULE_shortJoin = 26
    RULE_shortMandatory = 27
    RULE_shortInstantiation = 28
    RULE_valueConstraint = 29
    RULE_argumentList = 30
    RULE_argument = 31

    ruleNames =  [ "program", "declaration", "longFormDeclaration", "shortFormDeclaration", 
                   "typeConstructor", "instanceConstructor", "instanceOf", 
                   "subConstructorOf", "typeDefinition", "instDefinition", 
                   "predicate", "role", "function", "instantiation", "join", 
                   "mandatory", "shortTypeConstructor", "shortInstanceConstructor", 
                   "shortInstanceOf", "shortSubConstructorOf", "shortPartOf", 
                   "shortTypeDefinition", "shortInstDefinition", "shortPredicate", 
                   "shortRole", "shortFunction", "shortJoin", "shortMandatory", 
                   "shortInstantiation", "valueConstraint", "argumentList", 
                   "argument" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    PItem=9
    QItem=10
    ZItem=11
    CSM001=12
    CSM002=13
    CSM003=14
    CSM004=15
    CSM005=16
    CSM006=17
    CSM007=18
    CSM008=19
    CSM009=20
    CSM010=21
    CSM011=22
    CSM012=23
    CSM013=24
    CSM014=25
    VARIABLE=26
    DIGIT=27
    COMMA=28
    NUMBER=29
    STRING=30
    WS=31

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CoSMoParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(CoSMoParser.DeclarationContext,i)


        def getRuleIndex(self):
            return CoSMoParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = CoSMoParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 65 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 64
                self.declaration()
                self.state = 67 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 4063232) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def longFormDeclaration(self):
            return self.getTypedRuleContext(CoSMoParser.LongFormDeclarationContext,0)


        def shortFormDeclaration(self):
            return self.getTypedRuleContext(CoSMoParser.ShortFormDeclarationContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_declaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaration" ):
                listener.enterDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaration" ):
                listener.exitDeclaration(self)




    def declaration(self):

        localctx = CoSMoParser.DeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_declaration)
        try:
            self.state = 71
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 69
                self.longFormDeclaration()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 70
                self.shortFormDeclaration()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LongFormDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeConstructor(self):
            return self.getTypedRuleContext(CoSMoParser.TypeConstructorContext,0)


        def instanceConstructor(self):
            return self.getTypedRuleContext(CoSMoParser.InstanceConstructorContext,0)


        def instanceOf(self):
            return self.getTypedRuleContext(CoSMoParser.InstanceOfContext,0)


        def subConstructorOf(self):
            return self.getTypedRuleContext(CoSMoParser.SubConstructorOfContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_longFormDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLongFormDeclaration" ):
                listener.enterLongFormDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLongFormDeclaration" ):
                listener.exitLongFormDeclaration(self)




    def longFormDeclaration(self):

        localctx = CoSMoParser.LongFormDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_longFormDeclaration)
        try:
            self.state = 77
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [18]:
                self.enterOuterAlt(localctx, 1)
                self.state = 73
                self.typeConstructor()
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 2)
                self.state = 74
                self.instanceConstructor()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 3)
                self.state = 75
                self.instanceOf()
                pass
            elif token in [19]:
                self.enterOuterAlt(localctx, 4)
                self.state = 76
                self.subConstructorOf()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortFormDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def shortTypeConstructor(self):
            return self.getTypedRuleContext(CoSMoParser.ShortTypeConstructorContext,0)


        def shortInstanceConstructor(self):
            return self.getTypedRuleContext(CoSMoParser.ShortInstanceConstructorContext,0)


        def shortInstanceOf(self):
            return self.getTypedRuleContext(CoSMoParser.ShortInstanceOfContext,0)


        def shortSubConstructorOf(self):
            return self.getTypedRuleContext(CoSMoParser.ShortSubConstructorOfContext,0)


        def shortPartOf(self):
            return self.getTypedRuleContext(CoSMoParser.ShortPartOfContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_shortFormDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortFormDeclaration" ):
                listener.enterShortFormDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortFormDeclaration" ):
                listener.exitShortFormDeclaration(self)




    def shortFormDeclaration(self):

        localctx = CoSMoParser.ShortFormDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_shortFormDeclaration)
        try:
            self.state = 84
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [18]:
                self.enterOuterAlt(localctx, 1)
                self.state = 79
                self.shortTypeConstructor()
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 2)
                self.state = 80
                self.shortInstanceConstructor()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 3)
                self.state = 81
                self.shortInstanceOf()
                pass
            elif token in [19]:
                self.enterOuterAlt(localctx, 4)
                self.state = 82
                self.shortSubConstructorOf()
                pass
            elif token in [21]:
                self.enterOuterAlt(localctx, 5)
                self.state = 83
                self.shortPartOf()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeConstructorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM007(self):
            return self.getToken(CoSMoParser.CSM007, 0)

        def VARIABLE(self):
            return self.getToken(CoSMoParser.VARIABLE, 0)

        def typeDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CoSMoParser.TypeDefinitionContext)
            else:
                return self.getTypedRuleContext(CoSMoParser.TypeDefinitionContext,i)


        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_typeConstructor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeConstructor" ):
                listener.enterTypeConstructor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeConstructor" ):
                listener.exitTypeConstructor(self)




    def typeConstructor(self):

        localctx = CoSMoParser.TypeConstructorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_typeConstructor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 86
            self.match(CoSMoParser.CSM007)
            self.state = 87
            self.match(CoSMoParser.T__0)
            self.state = 88
            self.match(CoSMoParser.VARIABLE)
            self.state = 89
            self.match(CoSMoParser.T__1)
            self.state = 91 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 90
                self.typeDefinition()
                self.state = 93 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 79781888) != 0)):
                    break

            self.state = 95
            self.match(CoSMoParser.T__2)
            self.state = 97
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 96
                self.match(CoSMoParser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstanceConstructorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM006(self):
            return self.getToken(CoSMoParser.CSM006, 0)

        def VARIABLE(self):
            return self.getToken(CoSMoParser.VARIABLE, 0)

        def instDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CoSMoParser.InstDefinitionContext)
            else:
                return self.getTypedRuleContext(CoSMoParser.InstDefinitionContext,i)


        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_instanceConstructor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstanceConstructor" ):
                listener.enterInstanceConstructor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstanceConstructor" ):
                listener.exitInstanceConstructor(self)




    def instanceConstructor(self):

        localctx = CoSMoParser.InstanceConstructorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_instanceConstructor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self.match(CoSMoParser.CSM006)
            self.state = 100
            self.match(CoSMoParser.T__0)
            self.state = 101
            self.match(CoSMoParser.VARIABLE)
            self.state = 102
            self.match(CoSMoParser.T__1)
            self.state = 104 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 103
                self.instDefinition()
                self.state = 106 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 79716352) != 0)):
                    break

            self.state = 108
            self.match(CoSMoParser.T__2)
            self.state = 110
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 109
                self.match(CoSMoParser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstanceOfContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM009(self):
            return self.getToken(CoSMoParser.CSM009, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.COMMA)
            else:
                return self.getToken(CoSMoParser.COMMA, i)

        def getRuleIndex(self):
            return CoSMoParser.RULE_instanceOf

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstanceOf" ):
                listener.enterInstanceOf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstanceOf" ):
                listener.exitInstanceOf(self)




    def instanceOf(self):

        localctx = CoSMoParser.InstanceOfContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_instanceOf)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 112
            self.match(CoSMoParser.CSM009)
            self.state = 113
            self.match(CoSMoParser.T__1)
            self.state = 114
            self.match(CoSMoParser.VARIABLE)
            self.state = 115
            self.match(CoSMoParser.COMMA)
            self.state = 116
            self.match(CoSMoParser.VARIABLE)
            self.state = 117
            self.match(CoSMoParser.T__2)
            self.state = 119
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 118
                self.match(CoSMoParser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SubConstructorOfContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM008(self):
            return self.getToken(CoSMoParser.CSM008, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.COMMA)
            else:
                return self.getToken(CoSMoParser.COMMA, i)

        def getRuleIndex(self):
            return CoSMoParser.RULE_subConstructorOf

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSubConstructorOf" ):
                listener.enterSubConstructorOf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSubConstructorOf" ):
                listener.exitSubConstructorOf(self)




    def subConstructorOf(self):

        localctx = CoSMoParser.SubConstructorOfContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_subConstructorOf)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 121
            self.match(CoSMoParser.CSM008)
            self.state = 122
            self.match(CoSMoParser.T__1)
            self.state = 123
            self.match(CoSMoParser.VARIABLE)
            self.state = 124
            self.match(CoSMoParser.COMMA)
            self.state = 125
            self.match(CoSMoParser.VARIABLE)
            self.state = 126
            self.match(CoSMoParser.T__2)
            self.state = 128
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 127
                self.match(CoSMoParser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def predicate(self):
            return self.getTypedRuleContext(CoSMoParser.PredicateContext,0)


        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def role(self):
            return self.getTypedRuleContext(CoSMoParser.RoleContext,0)


        def shortRole(self):
            return self.getTypedRuleContext(CoSMoParser.ShortRoleContext,0)


        def function(self):
            return self.getTypedRuleContext(CoSMoParser.FunctionContext,0)


        def instantiation(self):
            return self.getTypedRuleContext(CoSMoParser.InstantiationContext,0)


        def join(self):
            return self.getTypedRuleContext(CoSMoParser.JoinContext,0)


        def mandatory(self):
            return self.getTypedRuleContext(CoSMoParser.MandatoryContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_typeDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeDefinition" ):
                listener.enterTypeDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeDefinition" ):
                listener.exitTypeDefinition(self)




    def typeDefinition(self):

        localctx = CoSMoParser.TypeDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_typeDefinition)
        self._la = 0 # Token type
        try:
            self.state = 157
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                self.enterOuterAlt(localctx, 1)
                self.state = 130
                self.predicate()
                self.state = 132
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 131
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 2)
                self.state = 136
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
                if la_ == 1:
                    self.state = 134
                    self.role()
                    pass

                elif la_ == 2:
                    self.state = 135
                    self.shortRole()
                    pass


                self.state = 139
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 138
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 3)
                self.state = 141
                self.function()
                self.state = 143
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 142
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 4)
                self.state = 145
                self.instantiation()
                self.state = 147
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 146
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 5)
                self.state = 149
                self.join()
                self.state = 151
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 150
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 6)
                self.state = 153
                self.mandatory()
                self.state = 155
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 154
                    self.match(CoSMoParser.COMMA)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def predicate(self):
            return self.getTypedRuleContext(CoSMoParser.PredicateContext,0)


        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def role(self):
            return self.getTypedRuleContext(CoSMoParser.RoleContext,0)


        def shortRole(self):
            return self.getTypedRuleContext(CoSMoParser.ShortRoleContext,0)


        def instantiation(self):
            return self.getTypedRuleContext(CoSMoParser.InstantiationContext,0)


        def join(self):
            return self.getTypedRuleContext(CoSMoParser.JoinContext,0)


        def mandatory(self):
            return self.getTypedRuleContext(CoSMoParser.MandatoryContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_instDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstDefinition" ):
                listener.enterInstDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstDefinition" ):
                listener.exitInstDefinition(self)




    def instDefinition(self):

        localctx = CoSMoParser.InstDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_instDefinition)
        self._la = 0 # Token type
        try:
            self.state = 182
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                self.enterOuterAlt(localctx, 1)
                self.state = 159
                self.predicate()
                self.state = 161
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 160
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 2)
                self.state = 165
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
                if la_ == 1:
                    self.state = 163
                    self.role()
                    pass

                elif la_ == 2:
                    self.state = 164
                    self.shortRole()
                    pass


                self.state = 168
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 167
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 3)
                self.state = 170
                self.instantiation()
                self.state = 172
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 171
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 4)
                self.state = 174
                self.join()
                self.state = 176
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 175
                    self.match(CoSMoParser.COMMA)


                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 5)
                self.state = 178
                self.mandatory()
                self.state = 180
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 179
                    self.match(CoSMoParser.COMMA)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PredicateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM003(self):
            return self.getToken(CoSMoParser.CSM003, 0)

        def PItem(self):
            return self.getToken(CoSMoParser.PItem, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_predicate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPredicate" ):
                listener.enterPredicate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPredicate" ):
                listener.exitPredicate(self)




    def predicate(self):

        localctx = CoSMoParser.PredicateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_predicate)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 184
            self.match(CoSMoParser.CSM003)
            self.state = 185
            self.match(CoSMoParser.T__1)
            self.state = 186
            self.match(CoSMoParser.PItem)
            self.state = 187
            self.match(CoSMoParser.T__1)
            self.state = 188
            self.match(CoSMoParser.VARIABLE)
            self.state = 189
            self.match(CoSMoParser.COMMA)
            self.state = 190
            self.match(CoSMoParser.VARIABLE)
            self.state = 191
            self.match(CoSMoParser.T__2)
            self.state = 192
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RoleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def QItem(self):
            return self.getToken(CoSMoParser.QItem, 0)

        def CSM002(self):
            return self.getToken(CoSMoParser.CSM002, 0)

        def CSM001(self):
            return self.getToken(CoSMoParser.CSM001, 0)

        def valueConstraint(self):
            return self.getTypedRuleContext(CoSMoParser.ValueConstraintContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_role

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRole" ):
                listener.enterRole(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRole" ):
                listener.exitRole(self)




    def role(self):

        localctx = CoSMoParser.RoleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_role)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 194
            self.match(CoSMoParser.VARIABLE)
            self.state = 198
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==4:
                self.state = 195
                self.match(CoSMoParser.T__3)
                self.state = 196
                self.match(CoSMoParser.VARIABLE)
                self.state = 197
                self.match(CoSMoParser.T__4)


            self.state = 200
            self.match(CoSMoParser.T__0)
            self.state = 201
            _la = self._input.LA(1)
            if not(_la==12 or _la==13):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 202
            self.match(CoSMoParser.T__1)
            self.state = 203
            self.match(CoSMoParser.QItem)
            self.state = 204
            self.match(CoSMoParser.T__2)
            self.state = 209
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==6:
                self.state = 205
                self.match(CoSMoParser.T__5)
                self.state = 206
                self.valueConstraint()
                self.state = 207
                self.match(CoSMoParser.T__6)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM005(self):
            return self.getToken(CoSMoParser.CSM005, 0)

        def ZItem(self):
            return self.getToken(CoSMoParser.ZItem, 0)

        def argumentList(self):
            return self.getTypedRuleContext(CoSMoParser.ArgumentListContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction" ):
                listener.enterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction" ):
                listener.exitFunction(self)




    def function(self):

        localctx = CoSMoParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 211
            self.match(CoSMoParser.CSM005)
            self.state = 212
            self.match(CoSMoParser.T__1)
            self.state = 213
            self.match(CoSMoParser.ZItem)
            self.state = 214
            self.match(CoSMoParser.T__1)
            self.state = 216
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1677725184) != 0):
                self.state = 215
                self.argumentList()


            self.state = 218
            self.match(CoSMoParser.T__2)
            self.state = 219
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstantiationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM002(self):
            return self.getToken(CoSMoParser.CSM002, 0)

        def QItem(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.QItem)
            else:
                return self.getToken(CoSMoParser.QItem, i)

        def getRuleIndex(self):
            return CoSMoParser.RULE_instantiation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstantiation" ):
                listener.enterInstantiation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstantiation" ):
                listener.exitInstantiation(self)




    def instantiation(self):

        localctx = CoSMoParser.InstantiationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_instantiation)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 221
            self.match(CoSMoParser.CSM002)
            self.state = 222
            self.match(CoSMoParser.T__1)
            self.state = 223
            self.match(CoSMoParser.QItem)
            self.state = 224
            self.match(CoSMoParser.T__2)
            self.state = 225
            self.match(CoSMoParser.T__7)
            self.state = 226
            self.match(CoSMoParser.T__5)
            self.state = 227
            self.match(CoSMoParser.QItem)
            self.state = 228
            self.match(CoSMoParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JoinContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM011(self):
            return self.getToken(CoSMoParser.CSM011, 0)

        def PItem(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.PItem)
            else:
                return self.getToken(CoSMoParser.PItem, i)

        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def QItem(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.QItem)
            else:
                return self.getToken(CoSMoParser.QItem, i)

        def getRuleIndex(self):
            return CoSMoParser.RULE_join

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJoin" ):
                listener.enterJoin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJoin" ):
                listener.exitJoin(self)




    def join(self):

        localctx = CoSMoParser.JoinContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_join)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 230
            self.match(CoSMoParser.CSM011)
            self.state = 231
            self.match(CoSMoParser.T__1)
            self.state = 232
            self.match(CoSMoParser.T__1)
            self.state = 239
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9]:
                self.state = 233
                self.match(CoSMoParser.PItem)
                self.state = 234
                self.match(CoSMoParser.COMMA)
                self.state = 235
                self.match(CoSMoParser.PItem)
                pass
            elif token in [10]:
                self.state = 236
                self.match(CoSMoParser.QItem)
                self.state = 237
                self.match(CoSMoParser.COMMA)
                self.state = 238
                self.match(CoSMoParser.QItem)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 241
            self.match(CoSMoParser.T__2)
            self.state = 242
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MandatoryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM012(self):
            return self.getToken(CoSMoParser.CSM012, 0)

        def VARIABLE(self):
            return self.getToken(CoSMoParser.VARIABLE, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_mandatory

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMandatory" ):
                listener.enterMandatory(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMandatory" ):
                listener.exitMandatory(self)




    def mandatory(self):

        localctx = CoSMoParser.MandatoryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_mandatory)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(CoSMoParser.CSM012)
            self.state = 245
            self.match(CoSMoParser.T__1)
            self.state = 246
            self.match(CoSMoParser.VARIABLE)
            self.state = 247
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortTypeConstructorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM007(self):
            return self.getToken(CoSMoParser.CSM007, 0)

        def VARIABLE(self):
            return self.getToken(CoSMoParser.VARIABLE, 0)

        def shortTypeDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CoSMoParser.ShortTypeDefinitionContext)
            else:
                return self.getTypedRuleContext(CoSMoParser.ShortTypeDefinitionContext,i)


        def getRuleIndex(self):
            return CoSMoParser.RULE_shortTypeConstructor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortTypeConstructor" ):
                listener.enterShortTypeConstructor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortTypeConstructor" ):
                listener.exitShortTypeConstructor(self)




    def shortTypeConstructor(self):

        localctx = CoSMoParser.ShortTypeConstructorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_shortTypeConstructor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 249
            self.match(CoSMoParser.CSM007)
            self.state = 250
            self.match(CoSMoParser.T__0)
            self.state = 251
            self.match(CoSMoParser.VARIABLE)
            self.state = 252
            self.match(CoSMoParser.T__1)
            self.state = 254 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 253
                self.shortTypeDefinition()
                self.state = 256 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 348130816) != 0)):
                    break

            self.state = 258
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortInstanceConstructorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM006(self):
            return self.getToken(CoSMoParser.CSM006, 0)

        def VARIABLE(self):
            return self.getToken(CoSMoParser.VARIABLE, 0)

        def shortInstDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CoSMoParser.ShortInstDefinitionContext)
            else:
                return self.getTypedRuleContext(CoSMoParser.ShortInstDefinitionContext,i)


        def getRuleIndex(self):
            return CoSMoParser.RULE_shortInstanceConstructor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortInstanceConstructor" ):
                listener.enterShortInstanceConstructor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortInstanceConstructor" ):
                listener.exitShortInstanceConstructor(self)




    def shortInstanceConstructor(self):

        localctx = CoSMoParser.ShortInstanceConstructorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_shortInstanceConstructor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 260
            self.match(CoSMoParser.CSM006)
            self.state = 261
            self.match(CoSMoParser.T__0)
            self.state = 262
            self.match(CoSMoParser.VARIABLE)
            self.state = 263
            self.match(CoSMoParser.T__1)
            self.state = 265 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 264
                self.shortInstDefinition()
                self.state = 267 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 348128768) != 0)):
                    break

            self.state = 269
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortInstanceOfContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM009(self):
            return self.getToken(CoSMoParser.CSM009, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortInstanceOf

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortInstanceOf" ):
                listener.enterShortInstanceOf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortInstanceOf" ):
                listener.exitShortInstanceOf(self)




    def shortInstanceOf(self):

        localctx = CoSMoParser.ShortInstanceOfContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_shortInstanceOf)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 271
            self.match(CoSMoParser.CSM009)
            self.state = 272
            self.match(CoSMoParser.T__1)
            self.state = 273
            self.match(CoSMoParser.VARIABLE)
            self.state = 274
            self.match(CoSMoParser.COMMA)
            self.state = 275
            self.match(CoSMoParser.VARIABLE)
            self.state = 276
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortSubConstructorOfContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM008(self):
            return self.getToken(CoSMoParser.CSM008, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortSubConstructorOf

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortSubConstructorOf" ):
                listener.enterShortSubConstructorOf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortSubConstructorOf" ):
                listener.exitShortSubConstructorOf(self)




    def shortSubConstructorOf(self):

        localctx = CoSMoParser.ShortSubConstructorOfContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_shortSubConstructorOf)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 278
            self.match(CoSMoParser.CSM008)
            self.state = 279
            self.match(CoSMoParser.T__1)
            self.state = 280
            self.match(CoSMoParser.VARIABLE)
            self.state = 281
            self.match(CoSMoParser.COMMA)
            self.state = 282
            self.match(CoSMoParser.VARIABLE)
            self.state = 283
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortPartOfContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM010(self):
            return self.getToken(CoSMoParser.CSM010, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortPartOf

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortPartOf" ):
                listener.enterShortPartOf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortPartOf" ):
                listener.exitShortPartOf(self)




    def shortPartOf(self):

        localctx = CoSMoParser.ShortPartOfContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_shortPartOf)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 285
            self.match(CoSMoParser.CSM010)
            self.state = 286
            self.match(CoSMoParser.T__1)
            self.state = 287
            self.match(CoSMoParser.VARIABLE)
            self.state = 288
            self.match(CoSMoParser.COMMA)
            self.state = 289
            self.match(CoSMoParser.VARIABLE)
            self.state = 290
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortTypeDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def shortPredicate(self):
            return self.getTypedRuleContext(CoSMoParser.ShortPredicateContext,0)


        def shortRole(self):
            return self.getTypedRuleContext(CoSMoParser.ShortRoleContext,0)


        def shortFunction(self):
            return self.getTypedRuleContext(CoSMoParser.ShortFunctionContext,0)


        def shortInstantiation(self):
            return self.getTypedRuleContext(CoSMoParser.ShortInstantiationContext,0)


        def shortJoin(self):
            return self.getTypedRuleContext(CoSMoParser.ShortJoinContext,0)


        def shortMandatory(self):
            return self.getTypedRuleContext(CoSMoParser.ShortMandatoryContext,0)


        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortTypeDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortTypeDefinition" ):
                listener.enterShortTypeDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortTypeDefinition" ):
                listener.exitShortTypeDefinition(self)




    def shortTypeDefinition(self):

        localctx = CoSMoParser.ShortTypeDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_shortTypeDefinition)
        try:
            self.state = 299
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9]:
                self.enterOuterAlt(localctx, 1)
                self.state = 292
                self.shortPredicate()
                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 2)
                self.state = 293
                self.shortRole()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 3)
                self.state = 294
                self.shortFunction()
                pass
            elif token in [10]:
                self.enterOuterAlt(localctx, 4)
                self.state = 295
                self.shortInstantiation()
                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 5)
                self.state = 296
                self.shortJoin()
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 6)
                self.state = 297
                self.shortMandatory()
                pass
            elif token in [28]:
                self.enterOuterAlt(localctx, 7)
                self.state = 298
                self.match(CoSMoParser.COMMA)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortInstDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def shortPredicate(self):
            return self.getTypedRuleContext(CoSMoParser.ShortPredicateContext,0)


        def shortRole(self):
            return self.getTypedRuleContext(CoSMoParser.ShortRoleContext,0)


        def shortInstantiation(self):
            return self.getTypedRuleContext(CoSMoParser.ShortInstantiationContext,0)


        def shortJoin(self):
            return self.getTypedRuleContext(CoSMoParser.ShortJoinContext,0)


        def shortMandatory(self):
            return self.getTypedRuleContext(CoSMoParser.ShortMandatoryContext,0)


        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortInstDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortInstDefinition" ):
                listener.enterShortInstDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortInstDefinition" ):
                listener.exitShortInstDefinition(self)




    def shortInstDefinition(self):

        localctx = CoSMoParser.ShortInstDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_shortInstDefinition)
        try:
            self.state = 307
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9]:
                self.enterOuterAlt(localctx, 1)
                self.state = 301
                self.shortPredicate()
                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 2)
                self.state = 302
                self.shortRole()
                pass
            elif token in [10]:
                self.enterOuterAlt(localctx, 3)
                self.state = 303
                self.shortInstantiation()
                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 4)
                self.state = 304
                self.shortJoin()
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 5)
                self.state = 305
                self.shortMandatory()
                pass
            elif token in [28]:
                self.enterOuterAlt(localctx, 6)
                self.state = 306
                self.match(CoSMoParser.COMMA)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortPredicateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PItem(self):
            return self.getToken(CoSMoParser.PItem, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortPredicate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortPredicate" ):
                listener.enterShortPredicate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortPredicate" ):
                listener.exitShortPredicate(self)




    def shortPredicate(self):

        localctx = CoSMoParser.ShortPredicateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_shortPredicate)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            self.match(CoSMoParser.PItem)
            self.state = 310
            self.match(CoSMoParser.T__1)
            self.state = 311
            self.match(CoSMoParser.VARIABLE)
            self.state = 312
            self.match(CoSMoParser.COMMA)
            self.state = 313
            self.match(CoSMoParser.VARIABLE)
            self.state = 314
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortRoleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.VARIABLE)
            else:
                return self.getToken(CoSMoParser.VARIABLE, i)

        def QItem(self):
            return self.getToken(CoSMoParser.QItem, 0)

        def valueConstraint(self):
            return self.getTypedRuleContext(CoSMoParser.ValueConstraintContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_shortRole

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortRole" ):
                listener.enterShortRole(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortRole" ):
                listener.exitShortRole(self)




    def shortRole(self):

        localctx = CoSMoParser.ShortRoleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_shortRole)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 316
            self.match(CoSMoParser.VARIABLE)
            self.state = 320
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==4:
                self.state = 317
                self.match(CoSMoParser.T__3)
                self.state = 318
                self.match(CoSMoParser.VARIABLE)
                self.state = 319
                self.match(CoSMoParser.T__4)


            self.state = 322
            self.match(CoSMoParser.T__0)
            self.state = 323
            self.match(CoSMoParser.QItem)
            self.state = 328
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==6:
                self.state = 324
                self.match(CoSMoParser.T__5)
                self.state = 325
                self.valueConstraint()
                self.state = 326
                self.match(CoSMoParser.T__6)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ZItem(self):
            return self.getToken(CoSMoParser.ZItem, 0)

        def argumentList(self):
            return self.getTypedRuleContext(CoSMoParser.ArgumentListContext,0)


        def valueConstraint(self):
            return self.getTypedRuleContext(CoSMoParser.ValueConstraintContext,0)


        def getRuleIndex(self):
            return CoSMoParser.RULE_shortFunction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortFunction" ):
                listener.enterShortFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortFunction" ):
                listener.exitShortFunction(self)




    def shortFunction(self):

        localctx = CoSMoParser.ShortFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_shortFunction)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 330
            self.match(CoSMoParser.ZItem)
            self.state = 331
            self.match(CoSMoParser.T__1)
            self.state = 332
            self.argumentList()
            self.state = 333
            self.match(CoSMoParser.T__2)
            self.state = 338
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==6:
                self.state = 334
                self.match(CoSMoParser.T__5)
                self.state = 335
                self.valueConstraint()
                self.state = 336
                self.match(CoSMoParser.T__6)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortJoinContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM011(self):
            return self.getToken(CoSMoParser.CSM011, 0)

        def PItem(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.PItem)
            else:
                return self.getToken(CoSMoParser.PItem, i)

        def COMMA(self):
            return self.getToken(CoSMoParser.COMMA, 0)

        def QItem(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.QItem)
            else:
                return self.getToken(CoSMoParser.QItem, i)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortJoin

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortJoin" ):
                listener.enterShortJoin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortJoin" ):
                listener.exitShortJoin(self)




    def shortJoin(self):

        localctx = CoSMoParser.ShortJoinContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_shortJoin)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 340
            self.match(CoSMoParser.CSM011)
            self.state = 341
            self.match(CoSMoParser.T__1)
            self.state = 342
            self.match(CoSMoParser.T__1)
            self.state = 349
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9]:
                self.state = 343
                self.match(CoSMoParser.PItem)
                self.state = 344
                self.match(CoSMoParser.COMMA)
                self.state = 345
                self.match(CoSMoParser.PItem)
                pass
            elif token in [10]:
                self.state = 346
                self.match(CoSMoParser.QItem)
                self.state = 347
                self.match(CoSMoParser.COMMA)
                self.state = 348
                self.match(CoSMoParser.QItem)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 351
            self.match(CoSMoParser.T__2)
            self.state = 352
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortMandatoryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM012(self):
            return self.getToken(CoSMoParser.CSM012, 0)

        def VARIABLE(self):
            return self.getToken(CoSMoParser.VARIABLE, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortMandatory

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortMandatory" ):
                listener.enterShortMandatory(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortMandatory" ):
                listener.exitShortMandatory(self)




    def shortMandatory(self):

        localctx = CoSMoParser.ShortMandatoryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_shortMandatory)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 354
            self.match(CoSMoParser.CSM012)
            self.state = 355
            self.match(CoSMoParser.T__1)
            self.state = 356
            self.match(CoSMoParser.VARIABLE)
            self.state = 357
            self.match(CoSMoParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShortInstantiationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QItem(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.QItem)
            else:
                return self.getToken(CoSMoParser.QItem, i)

        def getRuleIndex(self):
            return CoSMoParser.RULE_shortInstantiation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShortInstantiation" ):
                listener.enterShortInstantiation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShortInstantiation" ):
                listener.exitShortInstantiation(self)




    def shortInstantiation(self):

        localctx = CoSMoParser.ShortInstantiationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_shortInstantiation)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 359
            self.match(CoSMoParser.QItem)
            self.state = 360
            self.match(CoSMoParser.T__7)
            self.state = 361
            self.match(CoSMoParser.T__5)
            self.state = 362
            self.match(CoSMoParser.QItem)
            self.state = 363
            self.match(CoSMoParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueConstraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CSM014(self):
            return self.getToken(CoSMoParser.CSM014, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_valueConstraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueConstraint" ):
                listener.enterValueConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueConstraint" ):
                listener.exitValueConstraint(self)




    def valueConstraint(self):

        localctx = CoSMoParser.ValueConstraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_valueConstraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 365
            self.match(CoSMoParser.CSM014)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def argument(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CoSMoParser.ArgumentContext)
            else:
                return self.getTypedRuleContext(CoSMoParser.ArgumentContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(CoSMoParser.COMMA)
            else:
                return self.getToken(CoSMoParser.COMMA, i)

        def getRuleIndex(self):
            return CoSMoParser.RULE_argumentList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentList" ):
                listener.enterArgumentList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentList" ):
                listener.exitArgumentList(self)




    def argumentList(self):

        localctx = CoSMoParser.ArgumentListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_argumentList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 367
            self.argument()
            self.state = 372
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==28:
                self.state = 368
                self.match(CoSMoParser.COMMA)
                self.state = 369
                self.argument()
                self.state = 374
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QItem(self):
            return self.getToken(CoSMoParser.QItem, 0)

        def PItem(self):
            return self.getToken(CoSMoParser.PItem, 0)

        def ZItem(self):
            return self.getToken(CoSMoParser.ZItem, 0)

        def VARIABLE(self):
            return self.getToken(CoSMoParser.VARIABLE, 0)

        def NUMBER(self):
            return self.getToken(CoSMoParser.NUMBER, 0)

        def STRING(self):
            return self.getToken(CoSMoParser.STRING, 0)

        def getRuleIndex(self):
            return CoSMoParser.RULE_argument

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgument" ):
                listener.enterArgument(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgument" ):
                listener.exitArgument(self)




    def argument(self):

        localctx = CoSMoParser.ArgumentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_argument)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 375
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1677725184) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





